#include <iostream>

#include "AppliDeplacementPion.h"
#include "AppliTableau.h"

using namespace std;

int main()
{
    cout << "Demo tutoriel 1" << endl;

//    AppliDeplacementPion a1;
//    a1.run();

     AppliTableau a2;
     a2.run();


    return 0;
}

