#include <iostream>


#include "AppliAnimation.h"
#include "AppliDeplacementPion.h"

using namespace std;

int main()
{

    //AppliDeplacementPion a1;
    //a1.run();

    //AppliTableau a2;
    //a2.run();

    AppliAnimation a3;
    a3.run();

    return 0;
}

